<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />


	<link rel="profile" href="" />
	<link rel="pingback" href="" />
	 <img height= "9000px " src="http://ktcn.hvu.edu.vn/themes/ktcnv1/templates/images/banner.png">
	<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>

	<!-- This site is optimized with the Yoast SEO plugin v17.7.1 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Khoa Kỹ Thuật Công Nghệ</title>
	<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
	<link rel="canonical" href="" />
	<meta property="og:locale" content="vi_VN" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="Khoa Kỹ Thuật Công Nghệ" />
	<meta property="og:url" content="" />
	<meta property="og:site_name" content="Khoa Kỹ Thuật Công Nghệ" />
	<meta property="article:publisher" content="" />
	<meta property="article:modified_time" content="2023-10-23T00:40:56+00:00" />
	<meta name="twitter:card" content="summary" />
	<meta name="twitter:label1" content="Ước tính thời gian đọc" />
	<meta name="twitter:data1" content="3 phút" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"http://duocphutho.edu.vn/#organization","name":"Tr\u01b0\u1eddng Cao \u0111\u1eb3ng Y D\u01b0\u1ee3c Ph\u00fa Th\u1ecd","url":"http://duocphutho.edu.vn/","sameAs":["https://www.facebook.com/cdyduocpt","https://www.youtube.com/channel/UCxXdsteUJBX269swTWgLqVA"],"logo":{"@type":"ImageObject","@id":"http://duocphutho.edu.vn/#logo","inLanguage":"vi","url":"http://duocphutho.edu.vn/wp-content/uploads/2021/10/cropped-logo-.png","contentUrl":"http://duocphutho.edu.vn/wp-content/uploads/2021/10/cropped-logo-.png","width":512,"height":512,"caption":"Tr\u01b0\u1eddng Cao \u0111\u1eb3ng Y D\u01b0\u1ee3c Ph\u00fa Th\u1ecd"},"image":{"@id":"http://duocphutho.edu.vn/#logo"}},{"@type":"WebSite","@id":"http://duocphutho.edu.vn/#website","url":"http://duocphutho.edu.vn/","name":"Cao \u0111\u1eb3ng Y D\u01b0\u1ee3c Ph\u00fa Th\u1ecd","description":"","publisher":{"@id":"http://duocphutho.edu.vn/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"http://duocphutho.edu.vn/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"vi"},{"@type":"WebPage","@id":"http://duocphutho.edu.vn/#webpage","url":"http://duocphutho.edu.vn/","name":"Cao \u0111\u1eb3ng Y D\u01b0\u1ee3c Ph\u00fa Th\u1ecd","isPartOf":{"@id":"http://duocphutho.edu.vn/#website"},"about":{"@id":"http://duocphutho.edu.vn/#organization"},"datePublished":"2017-07-21T03:24:55+00:00","dateModified":"2023-10-23T00:40:56+00:00","breadcrumb":{"@id":"http://duocphutho.edu.vn/#breadcrumb"},"inLanguage":"vi","potentialAction":[{"@type":"ReadAction","target":["http://duocphutho.edu.vn/"]}]},{"@type":"BreadcrumbList","@id":"http://duocphutho.edu.vn/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Trang ch\u1ee7"}]}]}</script>
	<meta name="google-site-verification" content="dOeDXpmJyLIPdCgk17kumGhoElOWR1pALIUcoWANhv4" />
	


<link rel='dns-prefetch' href='//maxcdn.bootstrapcdn.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Dòng thông tin Cao đẳng Y Dược Phú Thọ &raquo;" href="http://duocphutho.edu.vn/feed/" />
<link rel="alternate" type="application/rss+xml" title="Dòng phản hồi Cao đẳng Y Dược Phú Thọ &raquo;" href="http://duocphutho.edu.vn/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/duocphutho.edu.vn\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.6.12"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	
<link rel='stylesheet' id='flatsome-main-css'  href='http://duocphutho.edu.vn/wp-content/themes/flatsome/assets/css/flatsome.css?ver=3.6.2' type='text/css' media='all'/>
<meta name="generator" content="WordPress 5.6.12" />
<link rel='shortlink' href='http://duocphutho.edu.vn/' />
<link rel="alternate" type="application/json+oembed" href="http://duocphutho.edu.vn/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fduocphutho.edu.vn%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://duocphutho.edu.vn/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fduocphutho.edu.vn%2F&#038;format=xml" />
<style>.bg{opacity: 0; transition: opacity 1s; -webkit-transition: opacity 1s;} .bg-loaded{opacity: 1;}</style><!--[if IE]><link rel="stylesheet" type="text/css" href="http://duocphutho.edu.vn/wp-content/themes/flatsome/assets/css/ie-fallback.css"><script src="//cdnjs.cloudflare.com/ajax/libs/html5shiv/3.6.1/html5shiv.js"></script><script>var head = document.getElementsByTagName('head')[0],style = document.createElement('style');style.type = 'text/css';style.styleSheet.cssText = ':before,:after{content:none !important';head.appendChild(style);setTimeout(function(){head.removeChild(style);}, 0);</script><script src="http://duocphutho.edu.vn/wp-content/themes/flatsome/assets/libs/ie-flexibility.js"></script><![endif]-->    <script type="text/javascript">
    WebFontConfig = {
      google: { families: [ "Helvetica,Arial,sans-serif:regular,700","Helvetica,Arial,sans-serif:regular,regular","Helvetica,Arial,sans-serif:regular,700","Helvetica,Arial,sans-serif", ] }
    };
    (function() {
      var wf = document.createElement('script');
      wf.src = 'https://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
      wf.type = 'text/javascript';
      wf.async = 'true';
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(wf, s);
    })(); </script>
  <link rel="icon" href="" sizes="32x32" />
<link rel="icon" href="" sizes="192x192" />
<link rel="apple-touch-icon" href="" />
<meta name="msapplication-TileImage" content="" />
<style id="custom-css" type="text/css">:root {--primary-color: #00a8b9;}html{background-color:#eeeeee!important;}/* Site Width */.full-width .ubermenu-nav, .container, .row{max-width: 1100px}.row.row-collapse{max-width: 1070px}.row.row-small{max-width: 1092.5px}.row.row-large{max-width: 1130px}body.framed, body.framed header, body.framed .header-wrapper, body.boxed, body.boxed header, body.boxed .header-wrapper, body.boxed .is-sticky-section{ max-width: 1100px}.header-main{height: 150px}#logo img{max-height: 150px}#logo{width:239px;}#logo img{padding:7px 0;}.header-bottom{min-height: 42px}.header-top{min-height: 30px}.has-transparent + .page-title:first-of-type,.has-transparent + #main > .page-title,.has-transparent + #main > div > .page-title,.has-transparent + #main .page-header-wrapper:first-of-type .page-title{padding-top: 200px;}.header.show-on-scroll,.stuck .header-main{height:70px!important}.stuck #logo img{max-height: 70px!important}.search-form{ width: 44%;}.header-bg-color, .header-wrapper {background-color: rgba(254,153,0,0)}.header-bg-image {background-image: url('');}.header-bg-image {background-repeat: repeat-x;}.header-bottom {background-color: #ffffff}.stuck .header-main .nav > li > a{line-height: 50px }.header-bottom-nav > li > a{line-height: 16px }@media (max-width: 549px) {.header-main{height: 70px}#logo img{max-height: 70px}}.nav-dropdown{font-size:100%}.header-top{background-color:rgba(94,94,94,0.42)!important;}/* Color */.accordion-title.active, .has-icon-bg .icon .icon-inner,.logo a, .primary.is-underline, .primary.is-link, .badge-outline .badge-inner, .nav-outline > li.active> a,.nav-outline >li.active > a, .cart-icon strong,[data-color='primary'], .is-outline.primary{color: #00a8b9;}/* Color !important */[data-text-color="primary"]{color: #00a8b9!important;}/* Background */.scroll-to-bullets a,.featured-title, .label-new.menu-item > a:after, .nav-pagination > li > .current,.nav-pagination > li > span:hover,.nav-pagination > li > a:hover,.has-hover:hover .badge-outline .badge-inner,button[type="submit"], .button.wc-forward:not(.checkout):not(.checkout-button), .button.submit-button, .button.primary:not(.is-outline),.featured-table .title,.is-outline:hover, .has-icon:hover .icon-label,.nav-dropdown-bold .nav-column li > a:hover, .nav-dropdown.nav-dropdown-bold > li > a:hover, .nav-dropdown-bold.dark .nav-column li > a:hover, .nav-dropdown.nav-dropdown-bold.dark > li > a:hover, .is-outline:hover, .tagcloud a:hover,.grid-tools a, input[type='submit']:not(.is-form), .box-badge:hover .box-text, input.button.alt,.nav-box > li > a:hover,.nav-box > li.active > a,.nav-pills > li.active > a ,.current-dropdown .cart-icon strong, .cart-icon:hover strong, .nav-line-bottom > li > a:before, .nav-line-grow > li > a:before, .nav-line > li > a:before,.banner, .header-top, .slider-nav-circle .flickity-prev-next-button:hover svg, .slider-nav-circle .flickity-prev-next-button:hover .arrow, .primary.is-outline:hover, .button.primary:not(.is-outline), input[type='submit'].primary, input[type='submit'].primary, input[type='reset'].button, input[type='button'].primary, .badge-inner{background-color: #00a8b9;}/* Border */.nav-vertical.nav-tabs > li.active > a,.scroll-to-bullets a.active,.nav-pagination > li > .current,.nav-pagination > li > span:hover,.nav-pagination > li > a:hover,.has-hover:hover .badge-outline .badge-inner,.accordion-title.active,.featured-table,.is-outline:hover, .tagcloud a:hover,blockquote, .has-border, .cart-icon strong:after,.cart-icon strong,.blockUI:before, .processing:before,.loading-spin, .slider-nav-circle .flickity-prev-next-button:hover svg, .slider-nav-circle .flickity-prev-next-button:hover .arrow, .primary.is-outline:hover{border-color: #00a8b9}.nav-tabs > li.active > a{border-top-color: #00a8b9}.widget_shopping_cart_content .blockUI.blockOverlay:before { border-left-color: #00a8b9 }.woocommerce-checkout-review-order .blockUI.blockOverlay:before { border-left-color: #00a8b9 }/* Fill */.slider .flickity-prev-next-button:hover svg,.slider .flickity-prev-next-button:hover .arrow{fill: #00a8b9;}/* Background Color */[data-icon-label]:after, .secondary.is-underline:hover,.secondary.is-outline:hover,.icon-label,.button.secondary:not(.is-outline),.button.alt:not(.is-outline), .badge-inner.on-sale, .button.checkout, .single_add_to_cart_button{ background-color:#00a8b9; }/* Color */.secondary.is-underline,.secondary.is-link, .secondary.is-outline,.stars a.active, .star-rating:before, .woocommerce-page .star-rating:before,.star-rating span:before, .color-secondary{color: #00a8b9}/* Color !important */[data-text-color="secondary"]{color: #00a8b9!important;}/* Border */.secondary.is-outline:hover{border-color:#00a8b9}body{font-size: 92%;}@media screen and (max-width: 549px){body{font-size: 90%;}}body{font-family:"Helvetica,Arial,sans-serif", sans-serif}body{font-weight: 0}.nav > li > a {font-family:"Helvetica,Arial,sans-serif", sans-serif;}.nav > li > a {font-weight: 700;}h1,h2,h3,h4,h5,h6,.heading-font, .off-canvas-center .nav-sidebar.nav-vertical > li > a{font-family: "Helvetica,Arial,sans-serif", sans-serif;}h1,h2,h3,h4,h5,h6,.heading-font,.banner h1,.banner h2{font-weight: 700;}.alt-font{font-family: "Helvetica,Arial,sans-serif", sans-serif;}.header:not(.transparent) .header-nav.nav > li > a {color: #fcfcfc;}.header:not(.transparent) .header-bottom-nav.nav > li > a{color: #000000;}.footer-1{background-image: url('http://duocphutho.edu.vn/wp-content/uploads/2018/10/bg_footer.jpg');}.footer-1{background-color: rgba(87,168,193,0.88)}.footer-2{background-color: #ffffff}.label-new.menu-item > a:after{content:"Mới ";}.label-hot.menu-item > a:after{content:"Hot";}.label-sale.menu-item > a:after{content:"Sale";}.label-popular.menu-item > a:after{content:"Phổ biến";}</style>	<meta property="fb:app_id" content="104537736801666" />
<meta property="" content=""/>

	<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.9&appId=104537736801666";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<script type="text/javascript">
	jQuery(function() {
    jQuery('marquee').mouseover(function() {
        jQuery(this).attr('scrollamount',0);
    }).mouseout(function() {
         jQuery(this).attr('scrollamount',5);
    });
});
</script>
</head>