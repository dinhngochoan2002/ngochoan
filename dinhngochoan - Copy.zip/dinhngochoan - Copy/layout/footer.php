<footer id="footer" class="footer-wrapper">

	

		</div>        
		</div><!-- end row -->
</div><!-- footer 1 -->


<!-- FOOTER 2 -->



<div class="absolute-footer dark medium-text-center small-text-center">
  <div class="container clearfix">

    
    <div class="footer-primary pull-left">
            <div class="copyright-footer">
              </div>
          </div><!-- .left -->
  </div><!-- .container -->
</div><!-- .absolute-footer -->
<a href="#top" class="back-to-top button invert plain is-outline hide-for-medium icon circle fixed bottom z-1" id="top-link"><i class="icon-angle-up" ></i></a>


</footer><!-- .footer-wrapper -->

</div><!-- #wrapper -->

<!-- Mobile Sidebar -->
<div id="main-menu" class="mobile-sidebar no-scrollbar mfp-hide">
    <div class="sidebar-menu no-scrollbar ">
        <ul class="nav nav-sidebar  nav-vertical nav-uppercase">
              <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-41 current_page_item menu-item-50"><a href="http://duocphutho.edu.vn/" class="nav-top-link">Trang chủ</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-231"><a href="http://duocphutho.edu.vn/gioi-thieu/" class="nav-top-link">Giới thiệu</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-357"><a href="http://duocphutho.edu.vn/category/dao-tao/" class="nav-top-link">Đào tạo</a>
<ul class=children>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2539"><a href="http://duocphutho.edu.vn/category/chuong-trinh-dao-tao/">Chương trình đào tạo</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-355"><a href="http://duocphutho.edu.vn/category/lich-hoc/">Lịch học</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-354"><a href="http://duocphutho.edu.vn/category/lich-thi/">Lịch thi</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-4275"><a href="http://duocphutho.edu.vn/category/dao-tao/tuyen-sinh/">Tuyển sinh</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-2561"><a href="http://duocphutho.edu.vn/category/van-ban-phap-quy/" class="nav-top-link">Văn bản pháp quy</a>
<ul class=children>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2559"><a href="http://duocphutho.edu.vn/category/pho-bien-phap-luat/">Phổ biến pháp luật</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2560"><a href="http://duocphutho.edu.vn/category/van-ban-cap-tren/">Văn bản cấp trên</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2562"><a href="http://duocphutho.edu.vn/category/van-ban-truong/">Văn bản trường</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-2400"><a href="http://duocphutho.edu.vn/category/dam-bao-chat-luong/" class="nav-top-link">Đảm bảo chất lượng</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-351"><a href="http://duocphutho.edu.vn/category/tin-tuc-su-kien/" class="nav-top-link">Tin tức &#8211; sự kiện</a>

</li>

</li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-2617"><a href="http://duocphutho.edu.vn/category/thu-vien/" class="nav-top-link">Thư viện</a>

</li>
        </ul>
    </div><!-- inner -->
</div><!-- #mobile-menu -->



</script>
<script type='text/javascript' src='http://duocphutho.edu.vn/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.0.4' id='contact-form-7-js'></script>
<script type='text/javascript' src='http://duocphutho.edu.vn/wp-content/themes/flatsome/inc/extensions/flatsome-live-search/flatsome-live-search.js?ver=3.6.2' id='flatsome-live-search-js'></script>
<script type='text/javascript' src='http://duocphutho.edu.vn/wp-includes/js/hoverIntent.min.js?ver=1.8.1' id='hoverIntent-js'></script>
<script type='text/javascript' id='flatsome-js-js-extra'>
/* <![CDATA[ */
var flatsomeVars = {"ajaxurl":"http:\/\/duocphutho.edu.vn\/wp-admin\/admin-ajax.php","rtl":"","sticky_height":"70","user":{"can_edit_pages":false}};
/* ]]> */
</script>
<script type='text/javascript' src='http://duocphutho.edu.vn/wp-content/themes/flatsome/assets/js/flatsome.js?ver=3.6.2' id='flatsome-js-js'></script>
<script type='text/javascript' src='http://duocphutho.edu.vn/wp-includes/js/wp-embed.min.js?ver=5.6.12' id='wp-embed-js'></script>

</body>
</html>