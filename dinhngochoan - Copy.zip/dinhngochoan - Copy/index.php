<?php
    $content = "content.php";
    include("layout/layout.php");
?>